from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def dashboard():
    return """
    <h1>Internal Dev Metrics Dashboard</h1>
    <p><strong>Status:</strong> Running</p>
    <p><strong>Environment:</strong> staging</p>
    <p><strong>Version:</strong> v0.9-dev</p>

    <hr>

    <p>Available endpoints:</p>
    <ul>
        <li>/metrics</li>
        <li>/health</li>
        <li>/config</li>
    </ul>

    <!-- NOTE: Remove staging services before production release -->
    """

@app.route("/metrics")
def metrics():
    return jsonify({
        "cpu_usage": "14%",
        "memory_usage": "512MB",
        "active_users": 3,
        "debug_mode": True
    })

@app.route("/health")
def health():
    return jsonify({
        "database": "connected",
        "cache": "connected",
        "admin_service": "running",
        "auth_service": "running"
    })

@app.route("/config")
def config():
    return jsonify({
        "environment": "staging",
        "admin_port": 8080,
        "debug": True,
        "internal_notes": "Disable debug_mode before prod push"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)