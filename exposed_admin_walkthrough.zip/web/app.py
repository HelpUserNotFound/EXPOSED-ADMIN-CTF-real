from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>Acme Corp | Enterprise Solutions</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f4f6f9;
            color: #333;
        }

        header {
            background-color: #1f2937;
            color: white;
            padding: 20px 40px;
        }

        header h1 {
            margin: 0;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: #9ca3af;
            text-decoration: none;
            margin-right: 20px;
            font-size: 14px;
        }

        nav a:hover {
            color: white;
        }

        .hero {
            padding: 60px 40px;
            background-color: white;
        }

        .hero h2 {
            font-size: 36px;
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 18px;
            max-width: 600px;
        }

        .features {
            display: flex;
            justify-content: space-around;
            padding: 40px;
            background-color: #e5e7eb;
        }

        .feature-box {
            background-color: white;
            padding: 20px;
            width: 28%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        .feature-box h3 {
            margin-top: 0;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #1f2937;
            color: #9ca3af;
            font-size: 14px;
        }

        .status {
            background-color: #10b981;
            color: white;
            padding: 10px;
            display: inline-block;
            border-radius: 4px;
            font-size: 14px;
            margin-top: 20px;
        }
    </style>
</head>

<body>

<header>
    <h1>Acme Corp</h1>
    <nav>
        <a href="#">Home</a>
        <a href="#">Solutions</a>
        <a href="#">Clients</a>
        <a href="#">Careers</a>
        <a href="#">Contact</a>
    </nav>
</header>

<section class="hero">
    <h2>Enterprise Infrastructure Solutions</h2>
    <p>
        Acme Corp provides secure, scalable enterprise software for
        businesses worldwide. Our platform ensures reliability,
        performance, and security at every layer.
    </p>

    <div class="status">
        System Status: Operational
    </div>
</section>

<section class="features">
    <div class="feature-box">
        <h3>Cloud Integration</h3>
        <p>Seamless deployment across hybrid and multi-cloud environments.</p>
    </div>

    <div class="feature-box">
        <h3>Security First</h3>
        <p>Built-in monitoring, encryption, and compliance tools.</p>
    </div>

    <div class="feature-box">
        <h3>24/7 Monitoring</h3>
        <p>Continuous system visibility and incident response support.</p>
    </div>
</section>

<footer>
    
</footer>

<!-- TODO: Remove internal admin interface before final production deployment -->

</body>
</html>
"""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)