from flask import Flask, request
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

USERS = {
    'admin': "admin",
    "user": "password"
}


@app.route("/")
def login():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>Acme Corp | Admin Portal</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #1f2937, #111827);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
        }

        .login-box {
            background-color: #1f2937;
            padding: 40px;
            border-radius: 8px;
            width: 320px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.4);
        }

        .login-box h2 {
            margin-top: 0;
            text-align: center;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border: none;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #10b981;
            border: none;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #059669;
        }

        .note {
            text-align: center;
            font-size: 12px;
            margin-top: 15px;
            color: #9ca3af;
        }
    </style>
</head>
<body>

<!-- 
Don't forget to delete page before publishing!!
thats not right!

Username: admin
Password: password
 -->

<div class="login-box">
    <h2>Admin Development Portal</h2>
    <form method="POST" action="/login">
        <input name="username" placeholder="Username">
        <input name="password" type="password" placeholder="Password"> 
        <button type="submit">Login</button>
    </form>
    <div class="note">
        Internal Use Only - Dev Environment
    </div>
</div>

</body>
</html>
"""

@app.route("/login", methods=["POST"])
def handle_login():
    username = request.form.get("username")
    password = request.form.get("password")

    if username in USERS and USERS[username] == password:
        return """
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            display: flex;
        }

        .sidebar {
            width: 220px;
            background-color: #111827;
            color: white;
            height: 100vh;
            padding: 20px;
        }

        .sidebar h3 {
            margin-top: 0;
        }

        .sidebar a {
            display: block;
            color: #9ca3af;
            text-decoration: none;
            margin: 10px 0;
        }

        .sidebar a:hover {
            color: white;
        }

        .content {
            flex: 1;
            padding: 40px;
            background-color: #f3f4f6;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        .status {
            color: #10b981;
            font-weight: bold;
        }

        .flag {
            background: #111827;
            color: #10b981;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="#">Dashboard</a>
    <a href="#">Users</a>
    <a href="#">System Logs</a>
    <a href="#">Configuration</a>
    <a href="#">Deployments</a>
</div>

<div class="content">
    <h1>System Overview</h1>

    <div class="card">
        <h3>Environment</h3>
        <p>Mode: <span class="status">Development</span></p>
        <p>Version: v1.3-dev</p>
    </div>

    <div class="card">
        <h3>Services</h3>
        <p>Web Service: Running</p>
        <p>Database: Connected</p>
        <p>Auth Service: Running</p>
    </div>

    <div class="card">
        <h3>Internal Deployment Token</h3>
        <div class="flag">FLAG{exposed_admin_port}</div>
    </div>

</div>

</body>
</html>
"""
    else:
        return "<h3>Invalid credentials</h3>"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)